<div class="my_meta_control" id="subtitle_metabox">
	<p>
		<?php $mb->the_field('subtitle'); ?>
		<input type="text" name="<?php $mb->the_name(); ?>" value="<?php $mb->the_value(); ?>" />
	</p>
</div>